import mybean.book_Bean;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.Part;
import java.util.UUID;

public class alter_Servlet extends HttpServlet{
	public void init(ServletConfig config)throws ServletException{
		super.init(config);
		try{ Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e){}
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		book_Bean alter_Bean=null;
		RequestDispatcher dispatcher=request.getRequestDispatcher("admin.jsp");
		try{
			alter_Bean=(book_Bean)request.getAttribute("alter_Bean");
			if(alter_Bean==null){
				alter_Bean=new book_Bean();
				request.setAttribute("alter_Bean",alter_Bean);
			}
		}
		catch(Exception exp){
			alter_Bean=new book_Bean();
			request.setAttribute("alter_Bean",alter_Bean);
		}
		request.setCharacterEncoding("utf-8");
		String dataBase="bookshop";
		String tableName="book";
		String ix=request.getParameter("index");
		String be=request.getParameter("bookname");
		String ct=request.getParameter("cost");
		String ar=request.getParameter("author");
		String ps=request.getParameter("press");
		String ie=request.getParameter("introduce");
		String de=request.getParameter("date");
		String at=request.getParameter("amount");
		System.out.println(ix+" "+be+" "+ct+" "+ar+" "+ps+" "+ie+" "+de+" "+at);
		/*Part part=request.getPart("pic");
		String name=part.getHeader("content-disposition");
		String root=request.getServletContext().getRealPath("/Pic");
		String str=name.substring(name.lastIndexOf("."), name.length()-1);
		String filename=root+"\\"+UUID.randomUUID().toString()+str;
		part.write(filename);*/
		String filename=null;
		int id=0;
		int a=Integer.parseInt(ix);
		float b=Float.parseFloat(ct);
		int c=Integer.parseInt(at);
		if(ix==null||ix.length()==0){
			alter_Bean.setResult("ʧ�ܣ�");
			dispatcher.forward(request,response);
			return;
		}
		String condition="SELECT * FROM "+tableName+" WHERE bookkey="+a;
		Connection con;
		System.out.println(condition);
		try{
			String uri="jdbc:mysql://127.0.0.1/"+dataBase+"?"+"user=root&password=123456&characterEncoding=utf-8&useSSL=true";			
			con=DriverManager.getConnection(uri);
			Statement sql=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs=sql.executeQuery(condition);
            if(!rs.next()){
            	sql.executeUpdate("INSERT INTO "+tableName+" VALUES"+"("+id+","+a+",'"+be+"',"+b+",'"+ar+"','"+ps+"','"+ie+"','"+de+"',"+c+",'"+filename+"')");
            }
            else {
            	sql.executeUpdate("UPDATE "+tableName+" SET bookname = "+"'"+be+"'"+" WHERE bookkey ="+a);
            	sql.executeUpdate("UPDATE "+tableName+" SET cost = "+b+" WHERE bookkey ="+a);
            	sql.executeUpdate("UPDATE "+tableName+" SET author = "+"'"+ar+"'"+" WHERE bookkey ="+a);
            	sql.executeUpdate("UPDATE "+tableName+" SET press = "+"'"+ps+"'"+" WHERE bookkey ="+a);
            	sql.executeUpdate("UPDATE "+tableName+" SET introduce = "+"'"+ie+"'"+" WHERE bookkey ="+a);
            	sql.executeUpdate("UPDATE "+tableName+" SET date = "+"'"+de+"'"+" WHERE bookkey ="+a);
            	sql.executeUpdate("UPDATE "+tableName+" SET amount = "+c+" WHERE bookkey ="+a);

            }			
			alter_Bean.setResult("�ɹ���");
			con.close();
			dispatcher.forward(request,response);
			return;
		}
		catch(SQLException ee){
			System.out.println(ee);
			alter_Bean.setResult("ʧ�ܣ�");
			dispatcher.forward(request,response);
			return ;
		}
	}
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{	
		doPost(request,response);
	}
	
}
